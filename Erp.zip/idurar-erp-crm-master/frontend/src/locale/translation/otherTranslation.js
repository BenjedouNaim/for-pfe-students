const languages = {};

export default languages;
