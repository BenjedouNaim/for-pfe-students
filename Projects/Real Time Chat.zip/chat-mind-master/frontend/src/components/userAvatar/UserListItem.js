import { Avatar } from "@chakra-ui/avatar";
import { Box, Text } from "@chakra-ui/layout";


const UserListItem = ({user, handleFunction }) => {


  return (
    <Box
 
    
      onClick={handleFunction}
      cursor="pointer"
      bg="#555770"
      _hover={{
        bg: "#6600CC",
        color: "white",
      }}
      w="100%"
      d="flex"
      alignItems="center"
      color="#F2F2F5" 
      py={2}
      mb={2}
      borderRadius="lg"
    >
      <Avatar
        mr={2}
        size="sm"
        cursor="pointer"
        name={user.name}
        src={user.pic}
      />
      <Box>
        <Text>{user.name}</Text>
        <Text fontSize="xs">
          <b>Email : </b>
          {user.email}
        </Text>
      </Box>
    </Box>
  );
};

export default UserListItem;
